// SPDX-License-Identifier: AGPL-3.0-or-later
package com.fractal.deepzoom

object Shaders {

    val VERTEX = """
        #version 310 es
        void main() {
            // One oversized triangle covering the clip volume. No vertex buffer needed.
            vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
            gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
        }
    """.trimIndent()

    private val COMMON = """
        precision highp float;
        precision highp int;
        precision highp sampler2D;

        out vec4 fragColor;

        uniform vec2  uResolution;
        uniform int   uMaxIter;

        uniform sampler2D uPalette;
        uniform float uCycle;      // iterations per full trip around the palette
        uniform float uOffset;
        uniform vec3  uInterior;

        uniform float uStripRBase;
        uniform float uStripRowBase;
        uniform float uStripStep;
        uniform float uStripWidth;

        uniform sampler2D uTiles;
        uniform int   uTileSize;
        uniform int   uUseTiles;

        // Colour depends only on the escape count, never on zoom. An escape count does
        // not change as you descend, so a pixel keeps its colour at any depth. The
        // palette is sampled with repeat wrapping, so no fract() is needed and the
        // seam blends.
        vec3 shade(int n, vec2 z) {
            float sn = float(n) + 1.0 - log2(0.5 * log2(dot(z, z)));
            return texture(uPalette, vec2(sn / uCycle + uOffset, 0.5)).rgb;
        }

        vec2 cmul(vec2 a, vec2 b) {
            return vec2(a.x * b.x - a.y * b.y, a.x * b.y + a.y * b.x);
        }

        // True when this pixel's tile was proven entirely interior by the border pass.
        bool tileIsSolid() {
            if (uUseTiles == 0) return false;
            ivec2 t = ivec2(gl_FragCoord.xy) / uTileSize;
            return texelFetch(uTiles, t, 0).r > 0.5;
        }
    """.trimIndent()

    /**
     * The border test behind tile skipping.
     *
     * If every pixel on a tile's border fails to escape within uMaxIter, so does every
     * pixel inside it. The truncated level set — points whose orbit stays bounded for
     * the first uMaxIter steps — is a closed topological disk, so its complement is
     * connected: an escaping point inside the tile would need a path to infinity
     * through escaping points, and that path has to cross the border. So this is exact,
     * not a heuristic, and it never touches the filaments.
     *
     * Written as a serial loop in one invocation per tile rather than as a compute
     * workgroup, specifically so it can bail the moment a border pixel escapes. Tiles
     * that straddle the boundary — the ones that cannot be skipped — therefore cost
     * close to nothing, and only genuinely solid tiles pay for the whole perimeter.
     */
    private val TILE_BODY = """
        void main() {
            ivec2 tile = ivec2(gl_FragCoord.xy);
            int x0 = tile.x * uTileSize;
            int y0 = tile.y * uTileSize;
            int x1 = min(x0 + uTileSize - 1, int(uResolution.x) - 1);
            int y1 = min(y0 + uTileSize - 1, int(uResolution.y) - 1);

            if (x0 > x1 || y0 > y1) { fragColor = vec4(0.0); return; }

            int n;
            vec2 z;

            for (int x = x0; x <= x1; x++) {
                if (escapes(vec2(float(x) + 0.5, float(y0) + 0.5), n, z)) {
                    fragColor = vec4(0.0); return;
                }
                if (y1 != y0 && escapes(vec2(float(x) + 0.5, float(y1) + 0.5), n, z)) {
                    fragColor = vec4(0.0); return;
                }
            }
            for (int y = y0 + 1; y < y1; y++) {
                if (escapes(vec2(float(x0) + 0.5, float(y) + 0.5), n, z)) {
                    fragColor = vec4(0.0); return;
                }
                if (x1 != x0 && escapes(vec2(float(x1) + 0.5, float(y) + 0.5), n, z)) {
                    fragColor = vec4(0.0); return;
                }
            }
            fragColor = vec4(1.0);
        }
    """.trimIndent()

    /** Direct float32 iteration, used above ~1e-4 span. */
    private val DIRECT_CORE = """
        uniform vec2  uCenter;
        uniform float uSpanY;

        // The main cardioid and period-2 bulb are the two largest solid regions.
        // Testing them analytically avoids running their pixels to uMaxIter.
        bool inMainBulbs(vec2 c) {
            float xm = c.x - 0.25;
            float y2 = c.y * c.y;
            float q  = xm * xm + y2;
            if (q * (q + xm) <= 0.25 * y2) return true;
            vec2 d = c + vec2(1.0, 0.0);
            return dot(d, d) <= 0.0625;
        }

        bool escapesOffset(vec2 off, out int outN, out vec2 outZ) {
            vec2 c = uCenter + off;
            outN = uMaxIter;
            outZ = vec2(0.0);

            if (inMainBulbs(c)) return false;

            vec2 z = vec2(0.0);
            float d = 0.0;
            int i;

            // Periodicity check: interior points settle into a cycle, and comparing
            // against a lazily-updated earlier value detects that in O(1) space.
            vec2 hare = vec2(0.0);
            int period = 1;
            int periodLimit = 1;

            for (i = 0; i < uMaxIter; i++) {
                z = vec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y) + c;
                d = dot(z, z);
                if (d > 65536.0) { outN = i; outZ = z; return true; }

                // Exact repeat, not an epsilon. If the float orbit lands on a value it
                // already held, it is periodic in float arithmetic and can never
                // escape, so stopping returns exactly what running to uMaxIter would.
                // An epsilon cannot be made safe here: escaping orbits near a minibrot
                // return to within a distance that scales with the atom, so any fixed
                // threshold starts marking escaping pixels interior once the zoom is
                // deep enough, which shows up as black speckles.
                if (z == hare) return false;
                period--;
                if (period == 0) {
                    hare = z;
                    periodLimit *= 2;
                    period = periodLimit;
                }
            }
            return false;
        }

        bool escapes(vec2 frag, out int outN, out vec2 outZ) {
            float pixelSpan = uSpanY / uResolution.y;
            return escapesOffset((frag - 0.5 * uResolution) * pixelSpan, outN, outZ);
        }
    """.trimIndent()

    /**
     * Perturbation, with rebasing and bivariate linear approximation.
     *
     * Each pixel tracks its offset d from a high-precision reference orbit Z:
     *
     *     d(n+1) = 2*Z(n)*d(n) + d(n)^2 + dc
     *
     * Z stays O(1) and d stays small, so both fit in float32 even where the true
     * coordinates need 60 decimal digits. Deltas are carried pre-multiplied by the
     * orbit's scale, because the true values sit below float32's denormal floor.
     *
     * Rebasing (Zhuoran) — when a pixel's true value falls below its own delta in
     * magnitude, the reference has stopped being informative, so the pixel restarts at
     * orbit index 0 carrying its full value forward. Exact, rather than detecting
     * glitched pixels heuristically and re-rendering them.
     *
     * BLA (Zhuoran) — where the squared term is negligible the recurrence is linear,
     * and composed runs of it are precomputed at every power-of-two length. A pixel
     * takes the longest jump whose validity radius contains its delta. Radii shrink
     * monotonically as levels merge, so the lookup climbs from level 0 and stops at the
     * first failure instead of searching.
     */
    private val PERTURB_CORE = """
        uniform sampler2D uOrbit;
        uniform sampler2D uBlaAB;
        uniform sampler2D uBlaR;

        uniform int   uWidthMask;
        uniform int   uWidthShift;
        uniform int   uOrbitLen;

        uniform int   uBlaLevels;
        uniform int   uBlaOffset[24];
        uniform int   uBlaCount[24];

        uniform vec2  uDeltaCenter;    // (view centre - reference), pre-scaled
        uniform float uPixelSpan;      // complex units per pixel, pre-scaled
        uniform float uInvScale;
        uniform float uHalfScale;      // scale/2, a power of two, so exact in float
        uniform float uDerLimit;       // squared derivative below which a point is interior
        uniform float uBailoutScaled;

        // Doubled reference orbit, 2*Z. The scaled form is this times uHalfScale.
        vec2 fetchZ(int i) {
            return texelFetch(uOrbit, ivec2(i & uWidthMask, i >> uWidthShift), 0).rg;
        }
        vec4 fetchAB(int i) {
            return texelFetch(uBlaAB, ivec2(i & uWidthMask, i >> uWidthShift), 0);
        }
        float fetchR(int i) {
            return texelFetch(uBlaR, ivec2(i & uWidthMask, i >> uWidthShift), 0).r;
        }

        // Highest level this reference index may use, before any radius is consulted.
        //
        // Alignment, the iteration cap and the per-level entry count are all monotone
        // in k, so this is a plain bound and costs no texture fetch. Alignment alone is
        // the trailing-zero count of m-1: level k needs m-1 to be a multiple of 2^k.
        int blaMaxLevel(int m, int n) {
            int a = m - 1;
            int k = uBlaLevels - 1;
            if (a != 0) k = min(k, findLSB(a));
            for (int i = 0; i < 24; i++) {
                if (k < 0) break;
                if (n + (1 << k) <= uMaxIter && (a >> k) < uBlaCount[k]) break;
                k--;
            }
            return k;
        }

        // 0.7 compensates for using the max-norm rather than the true length, which
        // would risk overflowing at this magnitude.
        bool blaValid(int k, int m, float dzMag) {
            return dzMag < fetchR(uBlaOffset[k] + ((m - 1) >> k)) * 0.7;
        }

        bool escapesOffset(vec2 off, out int outN, out vec2 outZ) {
            vec2 dc = uDeltaCenter + off;
            outN = uMaxIter;
            outZ = vec2(0.0);

            vec2 dz = vec2(0.0);
            int m = 0;
            int n = 0;
            vec2 t = fetchZ(0);

            // Level the BLA search settled on last iteration. Reset whenever the pixel
            // rebases, since that restarts dz at its full value and collapses the
            // usable prefix back to the bottom.
            int kWarm = 0;

            // Periodicity check, as the direct path does. The complete state here is
            // the delta together with the reference index -- two iterations can share a
            // value while sitting at different points of the reference orbit, and would
            // then continue differently. Comparing both makes an exact repeat a genuine
            // cycle of the computed iteration, so it provably never escapes.
            vec2 hareDz = vec2(0.0);
            int hareM = -1;
            int period = 1;
            int periodLimit = 1;

            // Derivative of the pixel's value with respect to its first iterate.
            //
            // An interior point is drawn into an attracting cycle, and what marks that
            // attraction is the derivative along the orbit collapsing toward zero. So
            // once it falls far enough the point cannot escape and there is nothing
            // left to compute.
            //
            // Taken with respect to the first iterate rather than the zeroth: the
            // orbit starts at the critical point, so the zeroth derivative carries a
            // factor of 2*0 and is identically zero, which says nothing. Starting a
            // step later is well defined, and is exact here because the reference is a
            // nucleus, where the orbit passes through zero.
            //
            // Nearly free. A plain step multiplies by twice the full value, which is
            // already to hand; a skipped run multiplies by that run's own A
            // coefficient, since z_{n+l} = A z_n + B c makes dz_{n+l}/dz_n exactly A,
            // and A has already been fetched to advance dz.
            //
            // It complements the cycle test rather than replacing it, and complements
            // the tile mask too: the mask skips solid blocks of interior, while this
            // catches interior pixels scattered among escaping ones, where no block is
            // ever solid.
            vec2 der = vec2(1.0, 0.0);

            while (n < uMaxIter) {
                float dzMag = max(abs(dz.x), abs(dz.y));

                int skip = 0;
                int chosen = -1;
                if (m >= 1) {
                    // Resume the level search where the last iteration settled.
                    //
                    // Radii are non-increasing as levels merge, and the alignment and
                    // bounds tests are monotone in k too, so the usable levels at any
                    // index form a prefix and only its end has to be found. Climbing
                    // from level 0 every time pays a fetch per level to rediscover an
                    // answer that moves by about a step at a time, because dz grows
                    // smoothly. Starting from the previous end turns that walk into a
                    // short local adjustment, and it returns the same level, so the
                    // image is unchanged.
                    int kMax = blaMaxLevel(m, n);
                    if (kMax >= 0) {
                        int k = clamp(kWarm, 0, kMax);
                        if (blaValid(k, m, dzMag)) {
                            for (int i = 0; i < 24; i++) {
                                if (k >= kMax || !blaValid(k + 1, m, dzMag)) break;
                                k++;
                            }
                            skip = 1 << k;
                            chosen = uBlaOffset[k] + ((m - 1) >> k);
                        } else {
                            for (int i = 0; i < 24; i++) {
                                if (k <= 0) break;
                                k--;
                                if (blaValid(k, m, dzMag)) {
                                    skip = 1 << k;
                                    chosen = uBlaOffset[k] + ((m - 1) >> k);
                                    break;
                                }
                            }
                            if (chosen < 0) k = 0;
                        }
                        kWarm = k;
                    }
                }

                if (chosen >= 0) {
                    vec4 ab = fetchAB(chosen);
                    if (n >= 1) der = cmul(der, ab.xy);
                    dz = cmul(ab.xy, dz) + cmul(ab.zw, dc);
                    n += skip;
                    m += skip;
                } else {
                    // Twice the full value at this step, unscaled: t is already twice
                    // the reference, and dz scaled back is the pixel's offset from it.
                    if (n >= 1) der = cmul(der, t + dz * (2.0 * uInvScale));
                    // d^2 in scaled units is d*(d/scale). Computed this way the
                    // intermediate stays in range; a plain d*d would overflow.
                    vec2 sq = cmul(dz, dz * uInvScale);
                    dz = cmul(t, dz) + sq + dc;
                    n++;
                    m++;
                }

                // Squared, to avoid a square root on the hot path.
                if (dot(der, der) < uDerLimit) return false;

                t = fetchZ(m);

                // True value, still scaled. Tests use the max-norm because a squared
                // length would overflow up here.
                vec2 zs = t * uHalfScale + dz;
                float zMag = max(abs(zs.x), abs(zs.y));

                if (zMag > uBailoutScaled) {
                    // Escaped values are O(1), so unscaling is safe here.
                    outN = n;
                    outZ = zs * uInvScale;
                    return true;
                }

                if (zMag < max(abs(dz.x), abs(dz.y)) || m >= uOrbitLen) {
                    dz = zs;
                    m = 0;
                    t = fetchZ(0);
                    kWarm = 0;
                }

                if (dz == hareDz && m == hareM) return false;
                period--;
                if (period == 0) {
                    hareDz = dz;
                    hareM = m;
                    periodLimit *= 2;
                    period = periodLimit;
                }
            }
            return false;
        }

        bool escapes(vec2 frag, out int outN, out vec2 outZ) {
            return escapesOffset((frag - 0.5 * uResolution) * uPixelSpan, outN, outZ);
        }
    """.trimIndent()

    private val MAIN_BODY = """
        void main() {
            if (tileIsSolid()) {
                fragColor = vec4(uInterior, 1.0);
                return;
            }
            int n;
            vec2 z;
            if (!escapes(gl_FragCoord.xy, n, z)) {
                fragColor = vec4(uInterior, 1.0);
                return;
            }
            fragColor = vec4(shade(n, z), 1.0);
        }
    """.trimIndent()


    /**
     * Renders rows of the exponential-map strip.
     *
     * The strip is the whole zoom in log-polar coordinates: horizontal is angle over
     * 2*pi, vertical is log radius from the zoom centre. Every scale in the zoom
     * appears exactly once, at exactly the resolution the animation needs, so no
     * iteration is ever computed twice across the whole video. Advancing the zoom by
     * one frame only extends the strip by a few rows, instead of recomputing a whole
     * frame's worth of pixels.
     *
     * The radius is built up multiplicatively from a per-chunk base rather than from
     * an absolute log, because at depth the absolute log radius is around -130 and a
     * float there has nowhere near enough resolution to separate adjacent rows.
     */
    /**
     * Alpha carries whether the pixel escaped: 0 for interior, 1 for escaped.
     *
     * The unwarp samples .rgb only, so alpha is spare, and it lets a single row be
     * tested for "nothing here escaped" by reading the row back. That is the whole
     * basis of skipping: a strip row is a full circle, and the exterior of the set is
     * connected and unbounded, so an escaping point inside a circle would need a path
     * to infinity crossing it. A circle with no escaping point therefore encloses none,
     * and every row below it can be filled without iterating.
     */
    private val STRIP_BODY = """
        void main() {
            float angle = (gl_FragCoord.x / uStripWidth) * 6.28318530718;
            float r = uStripRBase * exp((gl_FragCoord.y - uStripRowBase) * uStripStep);
            vec2 off = r * vec2(cos(angle), sin(angle));

            if (tileIsSolid()) {
                fragColor = vec4(uInterior, 0.0);
                return;
            }

            int n;
            vec2 z;
            if (!escapesOffset(off, n, z)) {
                fragColor = vec4(uInterior, 0.0);
                return;
            }
            fragColor = vec4(shade(n, z), 1.0);
        }
    """.trimIndent()

    /**
     * Border test for strip tiles.
     *
     * The whole-circle test only settles rows that are interior all the way round. At
     * the edge of a minibrot's atom rows are partly interior, and there the ordinary
     * tile border test wins instead — a tile is an annular sector, whose border is
     * still a closed curve in the plane, so the same connectivity argument applies.
     *
     * Rows here are absolute, not ring texels, so tiles keep their identity as the ring
     * wraps. That works because the ring height is a multiple of the tile size, so a
     * tile never straddles the wrap and texel/TILE equals absoluteRow/TILE modulo the
     * grid height.
     */
    private val STRIP_TILE_BODY = """
        void main() {
            ivec2 tile = ivec2(gl_FragCoord.xy);
            int x0 = tile.x * uTileSize;
            int x1 = min(x0 + uTileSize - 1, int(uStripWidth) - 1);
            float r0 = float(tile.y * uTileSize);
            float r1 = r0 + float(uTileSize - 1);

            if (x0 > x1) { fragColor = vec4(0.0); return; }

            int n;
            vec2 z;

            // Top and bottom edges.
            for (int x = x0; x <= x1; x++) {
                float a = ((float(x) + 0.5) / uStripWidth) * 6.28318530718;
                vec2 dir = vec2(cos(a), sin(a));
                float ra = uStripRBase * exp((r0 + 0.5 - uStripRowBase) * uStripStep);
                float rb = uStripRBase * exp((r1 + 0.5 - uStripRowBase) * uStripStep);
                if (escapesOffset(ra * dir, n, z)) { fragColor = vec4(0.0); return; }
                if (escapesOffset(rb * dir, n, z)) { fragColor = vec4(0.0); return; }
            }
            // Left and right edges, corners already covered above.
            for (int k = 1; k < uTileSize - 1; k++) {
                float rr = uStripRBase * exp((r0 + float(k) + 0.5 - uStripRowBase) * uStripStep);
                float al = ((float(x0) + 0.5) / uStripWidth) * 6.28318530718;
                float ar = ((float(x1) + 0.5) / uStripWidth) * 6.28318530718;
                if (escapesOffset(rr * vec2(cos(al), sin(al)), n, z)) {
                    fragColor = vec4(0.0); return;
                }
                if (x1 != x0 && escapesOffset(rr * vec2(cos(ar), sin(ar)), n, z)) {
                    fragColor = vec4(0.0); return;
                }
            }
            fragColor = vec4(1.0);
        }
    """.trimIndent()

    /**
     * Turns strip rows back into a normal frame.
     *
     * Both texture axes wrap: angle wraps at 2*pi, and the vertical axis is a ring
     * buffer holding only the rows the current frame needs. The seam between oldest
     * and newest row always falls outside that window, so linear filtering across it
     * never shows.
     */
    val UNWARP = """
        #version 310 es
        precision highp float;
        precision highp sampler2D;

        out vec4 fragColor;

        uniform sampler2D uStrip;
        uniform vec2  uResolution;
        uniform float uRingHeight;
        uniform float uRowBase;     // strip row for a one-pixel radius
        uniform float uStepInv;     // rows per unit of log radius
        uniform float uMinRadius;

        void main() {
            vec2 p = gl_FragCoord.xy - 0.5 * uResolution;
            // The few pixels at the very centre would need rows from arbitrarily deep
            // in the strip, so they are clamped to the innermost one available.
            float rpx = max(length(p), uMinRadius);
            float row = uRowBase + log(rpx) * uStepInv;
            fragColor = vec4(
                texture(uStrip, vec2(atan(p.y, p.x) / 6.28318530718, row / uRingHeight)).rgb,
                1.0
            );
        }
    """.trimIndent()

    val DIRECT = "#version 310 es\n$COMMON\n$DIRECT_CORE\n$MAIN_BODY"
    val DIRECT_TILE = "#version 310 es\n$COMMON\n$DIRECT_CORE\n$TILE_BODY"
    val PERTURBATION = "#version 310 es\n$COMMON\n$PERTURB_CORE\n$MAIN_BODY"
    val PERTURB_TILE = "#version 310 es\n$COMMON\n$PERTURB_CORE\n$TILE_BODY"
    val DIRECT_STRIP = "#version 310 es\n$COMMON\n$DIRECT_CORE\n$STRIP_BODY"
    val PERTURB_STRIP = "#version 310 es\n$COMMON\n$PERTURB_CORE\n$STRIP_BODY"
    val DIRECT_STRIP_TILE = "#version 310 es\n$COMMON\n$DIRECT_CORE\n$STRIP_TILE_BODY"
    val PERTURB_STRIP_TILE = "#version 310 es\n$COMMON\n$PERTURB_CORE\n$STRIP_TILE_BODY"

    /**
     * Presents an already-rendered frame, optionally reprojected.
     *
     * When the view has moved since the frame was made, the old frame is resampled
     * rather than recomputed, which costs one texture fetch per pixel.
     */
    val BLIT = """
        #version 310 es
        precision highp float;
        precision highp sampler2D;

        out vec4 fragColor;

        uniform sampler2D uScene;
        uniform vec2  uResolution;
        uniform vec2  uValidFrac;   // portion of the scene texture actually rendered
        uniform vec2  uShift;       // view movement since the frame was made
        uniform float uZoom;        // span ratio since the frame was made
        uniform vec3  uBackground;

        void main() {
            vec2 s = gl_FragCoord.xy / uResolution;
            vec2 q = vec2(0.5) + uShift + (s - vec2(0.5)) * uZoom;

            // Anything the old frame never covered stays background rather than
            // smearing edge pixels across newly exposed area.
            if (any(lessThan(q, vec2(0.0))) || any(greaterThan(q, vec2(1.0)))) {
                fragColor = vec4(uBackground, 1.0);
                return;
            }
            fragColor = vec4(texture(uScene, q * uValidFrac).rgb, 1.0);
        }
    """.trimIndent()
}
